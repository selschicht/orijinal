
const Impressum = () => (
  <div style={{ padding: '2em' }}>
    <h1>Impressum</h1>
    <p>Schichtwechsel Neckarsulm<br/>Inhaber: ...<br/>Adresse: ...<br/>E-Mail: wechselschicht5@gmail.com</p>
  </div>
);
export default Impressum;
