
const Datenschutz = () => (
  <div style={{ padding: '2em' }}>
    <h1>Datenschutzerklärung</h1>
    <p>Diese Website verwendet Cookies und speichert keine persönlichen Daten ohne Ihre Zustimmung.</p>
  </div>
);
export default Datenschutz;
