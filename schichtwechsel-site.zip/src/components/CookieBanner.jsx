
import { useEffect, useState } from 'react';

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem("cookiesAccepted");
    if (!accepted) setVisible(true);
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("cookiesAccepted", "true");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      width: '100%',
      background: '#222',
      color: 'white',
      padding: '1em',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      zIndex: 9999
    }}>
      <span>Bu web sitesi çerezleri kullanır. Kullanarak kabul etmiş olursunuz.</span>
      <button onClick={acceptCookies} style={{ marginLeft: '1em', padding: '0.5em' }}>Kabul Et</button>
    </div>
  );
};

export default CookieBanner;
