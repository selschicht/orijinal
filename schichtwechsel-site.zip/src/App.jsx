
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import CookieBanner from './components/CookieBanner';
import Impressum from './pages/Impressum';
import Datenschutz from './pages/Datenschutz';

function App() {
  return (
    <Router>
      <div>
        <nav style={{ padding: '1em', background: '#eee' }}>
          <Link to="/" style={{ marginRight: '1em' }}>Anasayfa</Link>
          <Link to="/impressum" style={{ marginRight: '1em' }}>Impressum</Link>
          <Link to="/datenschutz">Datenschutz</Link>
        </nav>
        <Routes>
          <Route path="/" element={<h1 style={{ padding: '2em' }}>Schichtwechsel Neckarsulm</h1>} />
          <Route path="/impressum" element={<Impressum />} />
          <Route path="/datenschutz" element={<Datenschutz />} />
        </Routes>
        <CookieBanner />
      </div>
    </Router>
  );
}

export default App;
